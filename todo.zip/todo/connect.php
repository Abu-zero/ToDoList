<?php
$servername = "localhost";
$database = "todo";
$username = "root";
$password = "";
$baglan = new mysqli("$servername", "$username", "$password", "$database");
$baglan->set_charset("utf8");
$charset="utf8";
?>
